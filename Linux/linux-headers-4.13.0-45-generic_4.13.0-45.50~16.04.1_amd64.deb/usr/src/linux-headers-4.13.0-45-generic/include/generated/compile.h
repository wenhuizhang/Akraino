/* This file is auto generated, version 50~16.04.1 */
/* SMP */
#define UTS_MACHINE "x86_64"
#define UTS_VERSION "#50~16.04.1 SMP Sat Jul 7 00:44:20 EDT 2018"
#define LINUX_COMPILE_BY "root"
#define LINUX_COMPILE_HOST "bunsen2.cs.unc.edu"
#define LINUX_COMPILER "gcc version 5.5.0 20171010 (Ubuntu 5.5.0-12ubuntu1~14.04)"
